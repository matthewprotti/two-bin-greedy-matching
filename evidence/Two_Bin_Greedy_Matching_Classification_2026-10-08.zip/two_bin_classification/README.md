# Two-bin greedy matching: sharp classification

**8 October 2026. New paper proof; exact finite author-side checks; no independent review or Lean build for the classification. No novelty/priority claim.**

For positive integer capacities `a <= b`, RV stochastically dominates uniformly randomized RK for every finite degree word **if and only if**

```text
(b-a)^2 <= a+b-2.
```

The same condition is necessary and sufficient when arrivals are independently uniformly randomized and the comparison is required for every finite degree multiset. Singleton neighborhoods must be independent and uniform. This is not a per-fixed-graph or unrandomized-priority claim.

`PROOF.md` is self-contained. In particular, it does not require acceptance of the historical gap-two addendum or any recent equal-capacity manuscript.

## Main additions

- A paired falling-factorial inequality, with an elementary product/secant proof, establishes all first-saturation comparisons under the quadratic condition.
- The unchanged idea of a common continuation kernel converts them to final matching-size comparisons.
- Every excluded pair has a fixed-order reversal with two flexible jobs and `a+b-3` singletons.
- A separate exact averaging calculation proves a reversal for that same multiset under uniform random arrivals. Averaging a single bad order would not have sufficed.
- Universal equality, universal reverse dominance, and absence of a universal ordering are classified as well.

## Files and reading order

Read `PROOF.md`, then `REVIEW_BRIEF.md`, then `RESULTS.json`. `model.py` contains exact process, saturation, classification and witness calculations; `oracle.py` explicitly enumerates small sample spaces without importing `model.py`. `algebra.py` checks six rational-polynomial identities by coefficient expansion. `check.py` recomputes the evidence. `REPLAY.py` verifies manifest membership and hashes, then executes in a fresh temporary copy and compares substantive evidence exactly.

`history/Matching_Gap_Two_Addendum_2026-10-08.zip` is unchanged. It includes the earlier first-attack archive. `SOURCE_BINDINGS.json` records hashes of all three upstream archives. Historical source is not overwritten or silently upgraded to a new verification status.

## Reproduction

Requires Python 3.10 or later and only its standard library. No external network, solver, model provider, or API key is required.

```sh
python -B REPLAY.py
python -B check.py classify 6 10
python -B check.py classify 7 11
```

The complete replay took approximately 26 seconds in the preparation environment; this is a local observation, not a performance guarantee. Timings are excluded from the sealed substantive evidence.

For a fresh receipt without overwriting the package:

```sh
python -B check.py verify --emit /tmp/two-bin-new-receipt.json
```

The destination must not already exist or be inside the package.

## Evidence versus proof

The finite checks are falsification/cross-checking evidence. The all-parameter claims rest on `PROOF.md`. Multiple implementations were authored in the same session and do not constitute independent review. Custom polynomial expansion is not Lean verification. No theorem for three or more bins is claimed or tested in this release.

Recommended next gate: an adversarial review of the consolidated classification, especially the paired-factorial lemma and the independent random-order necessity argument. Reopen three bins only after evaluating that review and the potential value of the next theorem.
