"""Replay exact evidence, or inspect one two-bin classification.

Usage:
  python check.py verify
  python check.py verify --emit /absolute/path/outside-this-package/results.json
  python check.py classify 6 10

Only the paper proof claims universal correctness. Tests are finite author-side
checks. No Lean or independent reviewer acceptance is implied.
"""
from __future__ import annotations
import argparse
from collections import defaultdict
from fractions import Fraction as F
import hashlib
from itertools import product
import json
from math import comb
from pathlib import Path
import time
import zipfile
import model as m
from oracle import enumerate_distribution
from algebra import verify_identities

ROOT = Path(__file__).resolve().parent

def require(ok, detail):
    if not ok:
        raise AssertionError(detail)

def digest_row(digest, row):
    digest.update((json.dumps(row,separators=(',',':'),sort_keys=True)+'\n').encode())

def parent_integrity():
    p = ROOT/'history'/'Matching_Gap_Two_Addendum_2026-10-08.zip'
    with zipfile.ZipFile(p) as z:
        manifest = json.loads(z.read('gap_two_addendum/MANIFEST.json'))
        records = manifest.get('files',manifest)
        count = 0
        for name, rec in records.items():
            # Existing manifest has named bytes and SHA-256 records.
            if not isinstance(rec,dict) or 'sha256' not in rec:
                continue
            data = z.read('gap_two_addendum/'+name)
            require(hashlib.sha256(data).hexdigest() == rec['sha256'],name)
            if 'bytes' in rec:
                require(len(data) == rec['bytes'],name)
            count += 1
    return {'archive_sha256': hashlib.sha256(p.read_bytes()).hexdigest(),
            'manifest_entries_checked':count,
            'historical_full_replays':'NOT_RERUN; immutable archive retained'}

def coefficient_checks():
    checks = 0
    pairs = 0
    h = hashlib.sha256()
    # Exhaustive u,v in the domain needed by the proof, for all admissible
    # r<=q with r+q<=100. Falling factorials are precomputed by multiplication.
    for N in range(101):
        for r in range(N//2+1):
            q=N-r; d=q-r
            if d*d>N:
                continue
            pairs += 1
            fr=[1]; fq=[1]
            for k in range(1,N+1):
                fr.append(fr[-1]*(r-k+1) if k<=r else 0)
                fq.append(fq[-1]*(q-k+1) if k<=q else 0)
            for u in range(N+1):
                for v in range(N-u+1):
                    gap=fr[u]*fq[v]+fq[u]*fr[v]-fr[u+v]-fq[u+v]
                    require(gap>=0,('factorial',r,q,u,v,gap))
                    checks += 1
                    digest_row(h,[r,q,u,v,str(gap)])
    product_checks=secant_checks=0
    boundary_pairs=[]
    for d in range(2,101):
        r0=d*(d-1)//2
        for r in (r0,r0+1,r0+7):
            q=r+d
            for u in range(1,d):
                # Product bound, cleared of denominators.
                fu,fq=m.falling(r,u),m.falling(q,u)
                require((d+u)*fu>=(d-u)*fq,('product',r,d,u))
                product_checks += 1
            # Test the secant inequality throughout the interior domain.
            # A bounded d<=30 subset keeps the replay lightweight.
            if d<=30:
                for u in range(1,d):
                    for v in range(1,d):
                        inner=m.falling(q-u,v)-m.falling(r,v)
                        outer=m.falling(q,v)-m.falling(r-u,v)
                        require((d+u)*inner<=(d-u)*outer,('secant',r,d,u,v))
                        secant_checks += 1
        # Values immediately on either side of each quadratic boundary.
        for r in (r0-1,r0,r0+1):
            caps=(r+1,r+d+1)
            require(m.classification(caps)['rv_universal']==(r>=r0),caps)
            fixed=m.fixed_witness_gap(caps)
            require((fixed<0)==(r<r0),('boundary fixed',caps,fixed))
            if r<r0:
                require(m.random_witness_gap(caps)<0,('boundary random',caps))
            boundary_pairs.append({'capacities':list(caps),'rv_universal':r>=r0,
                                   'fixed_gap_sign':(fixed>0)-(fixed<0)})
    return {'admissible_rq_pairs':pairs,'N_max':100,
            'falling_factorial_inequalities':checks,'stream_sha256':h.hexdigest(),
            'product_bound_checks':product_checks,'symmetric_secant_checks':secant_checks,
            'large_boundary_gaps_tested':[2,100],'boundary_cases':len(boundary_pairs),
            'boundary_case_stream_sha256':hashlib.sha256(json.dumps(boundary_pairs,sort_keys=True).encode()).hexdigest()}

def prefix_checks():
    count=pairs=passes=failures=mono=0
    h=hashlib.sha256()
    regimes=defaultdict(int)
    examples=[]
    for a in range(1,65):
        for b in range(a,65):
            caps=(a,b); N=a+b-2; expected=m.classification(caps)
            pairs += 1; regimes[expected['regime']] += 1
            allpass=True; first=None
            for t in range(N+1):
                v_prev_r=None
                for s in range(t+1):
                    v,r=m.survival_numerators(caps,t,s)
                    gap=v-r
                    count += 1
                    if gap<0:
                        allpass=False
                        if first is None:
                            first=(t,s)
                    if a==1:
                        require(gap<=0,('capacity one reverse',caps,t,s,gap))
                    if expected['rv_universal']:
                        require(gap>=0,('universal prefix',caps,t,s,gap))
                        if v_prev_r is not None:
                            require(r>=v_prev_r,('singleton monotonicity',caps,t,s))
                            mono += 1
                    v_prev_r=r
                    digest_row(h,[a,b,t,s,str(gap)])
            require(allpass==expected['rv_universal'],('criterion',caps,first))
            if allpass: passes+=1
            else: failures+=1
            if caps in [(1,1),(1,2),(1,3),(2,4),(3,6),(4,7),(6,10),(7,11),(10,15),(11,16)]:
                examples.append({**expected,'first_failed_prefix':list(first) if first is not None else None})
    return {'capacity_max':64,'pairs':pairs,'all_prefix_inequalities':count,
            'all_prefix_pass_pairs':passes,'all_prefix_fail_pairs':failures,
            'ranking_singleton_monotonicity_checks':mono,
            'regimes':dict(sorted(regimes.items())), 'stream_sha256':h.hexdigest(),
            'selected_pairs':examples}

def direct_checks():
    profiles=tail_checks=kernel=literal=sample_points=zero=swaps=0
    h=hashlib.sha256()
    # Exhaustive fixed words through 10 jobs, capacity pairs through 10.
    # Prefix-sharing avoids recomputing the same state distributions.
    for a in range(1,11):
        for b in range(a,11):
            caps=(a,b); cl=m.classification(caps)
            def visit(seq,rv,r0,r1):
                nonlocal profiles,tail_checks,kernel,literal,sample_points
                n=len(seq)
                laws=[m.size_counts(x) for x in (rv,r0,r1)]
                require(all(sum(x.values())==1<<n for x in laws),('normalization',caps,seq))
                profiles += 1
                gaps=[]
                for K in range(a+b+2):
                    g=2*sum(v for k,v in laws[0].items() if k>=K)
                    g-=sum(v for k,v in laws[1].items() if k>=K)
                    g-=sum(v for k,v in laws[2].items() if k>=K)
                    if cl['rv_universal']:
                        require(g>=0,('RV process',caps,seq,K,g))
                    if a==1:
                        require(g<=0,('RK process',caps,seq,K,g))
                    tail_checks += 1
                    gaps.append(g)
                digest_row(h,[caps,seq,gaps])
                if n<=7:
                    p0={k:F(v,1<<n) for k,v in laws[0].items()}
                    pr={k:F(laws[1].get(k,0)+laws[2].get(k,0),1<<(n+1))
                        for k in laws[1].keys()|laws[2].keys()}
                    for alg,law in (('rv',p0),('ranking',pr)):
                        require(law==m.kernel_distribution(caps,seq,alg),('kernel',caps,seq,alg))
                        kernel+=1
                        if b<=6:
                            obs,samples=enumerate_distribution(caps,seq,alg)
                            require(obs==law,('literal',caps,seq,alg))
                            literal+=1; sample_points+=samples
                if n<10:
                    for degree in (1,2):
                        visit(seq+(degree,),*(m.advance(x,caps,degree,alg)
                              for x,alg in zip((rv,r0,r1),m.ALGORITHMS)))
            visit((),{(0,0):1},{(0,0):1},{(0,0):1})
            for seq in [(),(0,),(0,2,0,1),(1,0,2,2,0,1),(2,2,1,1,2,1)]:
                for alg in ('rv','ranking'):
                    p=m.process_distribution(caps,seq,alg)
                    require(p==m.process_distribution(caps,tuple(d for d in seq if d),alg),('zero',caps,seq))
                    require(p==m.kernel_distribution(caps,seq,alg),('zero kernel',caps,seq))
                    zero+=1
                    require(p==m.process_distribution(caps[::-1],seq,alg),('swap',caps,seq))
                    swaps+=1
    return {'capacity_max':10,'max_positive_jobs':10,'fixed_word_profiles_including_empty':profiles,
            'exact_tail_comparisons':tail_checks,'kernel_full_distribution_crosschecks':kernel,
            'literal_full_distribution_crosschecks':literal,'literal_sample_points':sample_points,
            'degree_zero_controls':zero,'label_swap_controls':swaps,'stream_sha256':h.hexdigest()}

def witness_checks():
    formula=direct_fixed=direct_random=strict=assumption=0
    h=hashlib.sha256(); examples=[]
    for a in range(1,65):
        for b in range(a,65):
            caps=(a,b); N=a+b-2; d=b-a
            if N<2:
                continue
            fgap=m.fixed_witness_gap(caps)
            rgap=m.random_witness_gap(caps)
            require(rgap==m.random_witness_sum(caps),('random polynomial',caps))
            v,r=m.survival_numerators(caps,N,N-2)
            require(fgap==F(v-r,1<<(N+2)),('fixed polynomial',caps))
            formula += 2
            if d*d>N:
                require(fgap<0 and rgap<0,('excluded pair',caps))
            else:
                require(fgap>=0 and rgap>=0,('admitted pair',caps))
            if b<=24:
                seq=(1,)*(N-2)+(2,2,1)
                rv=m.process_distribution(caps,seq,'rv')
                rk=m.process_distribution(caps,seq,'ranking')
                require(rv.get(N+1,F(0))-rk.get(N+1,F(0))==fgap,('fixed witness DP',caps))
                # Only the top tail differs for this fixed witness.
                for K in range(N+2):
                    actual=sum(p for k,p in rv.items() if k>=K)-sum(p for k,p in rk.items() if k>=K)
                    require(actual==(fgap if K==N+1 else 0),('single tail support',caps,K))
                direct_fixed+=1
                rv=m.random_order_distribution(caps,N-1,2,'rv')
                rk=m.random_order_distribution(caps,N-1,2,'ranking')
                require(rv.get(N+1,F(0))-rk.get(N+1,F(0))==rgap,('random witness DP',caps))
                direct_random+=1
                if caps in [(1,3),(2,5),(3,6),(4,7),(6,10),(7,11),(10,15),(11,16)]:
                    examples.append({'capacities':list(caps),'fixed_order_rv_minus_rk':str(fgap),
                                     'random_order_rv_minus_rk':str(rgap),
                                     'random_order_rv_all_matched':str(rv.get(N+1,F(0))),
                                     'random_order_rk_all_matched':str(rk.get(N+1,F(0))),
                                     'random_profile':{'singletons':N-1,'flexibles':2},'threshold':N+1})
            if a>=2 and b<=24:
                seq=(2,)*a+(1,)
                rv=m.process_distribution(caps,seq,'rv').get(a+1,F(0))
                rk=m.process_distribution(caps,seq,'ranking').get(a+1,F(0))
                expected=F(1,2)-F(1,1<<a) if a==b else F(1,4)-F(1,1<<(a+1))
                require(rv-rk==expected and expected>0,('RV strict fixed',caps))
                rv=m.random_order_distribution(caps,1,a,'rv').get(a+1,F(0))
                rk=m.random_order_distribution(caps,1,a,'ranking').get(a+1,F(0))
                require(rv-rk==expected/(a+1),('RV strict random',caps))
                strict+=2
            digest_row(h,[a,b,str(fgap),str(rgap)])
    # The fair prior on RK priorities cannot be dropped.
    rv=m.process_distribution((1,2),(2,1),'rv')[2]
    large=m.process_distribution((1,2),(2,1),'rank1')[2]
    require(rv==F(3,4) and large==1,'fixed priority control')
    assumption+=1
    for caps in [(0,1),(1,-1),(True,2)]:
        try:
            m.classification(caps)
        except ValueError:
            assumption+=1
        else:
            raise AssertionError(('invalid capacity accepted',caps))
    return {'capacity_max_formula_checks':64,'closed_formula_identity_checks':formula,
            'capacity_max_full_witness_dp':24,'fixed_witness_distribution_checks':direct_fixed,
            'uniform_order_witness_distribution_checks':direct_random,
            'rv_strict_example_checks':strict,'assumption_and_input_controls':assumption,
            'stream_sha256':h.hexdigest(),'examples':examples}

def run():
    sections={}
    for name,fn in [('parent_integrity',parent_integrity),('algebra',verify_identities),('coefficients',coefficient_checks),
                    ('prefixes',prefix_checks),('direct_process',direct_checks),('witnesses',witness_checks)]:
        start=time.perf_counter()
        sections[name]=fn()
        print(f'{name}: PASS ({time.perf_counter()-start:.2f}s)',flush=True)
    return {'schema':'two-bin-classification-evidence.v1','date':'2026-10-08',
            'claim_status':'COMPLETE_PAPER_PROOF_WITH_EXACT_FINITE_AUTHOR_SIDE_CHECKS',
            'new_result_external_review':'NOT_OBTAINED','lean':'NOT_RUN',
            'novelty_priority':'NOT_CLEARED',
            'three_or_more_bins':'NO_THEOREM_CLAIMED_OR_RUN_IN_THIS_PACKAGE',
            'software_independence':'Different algorithms, same authoring session; not external independent review.',
            **sections}

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    commands=parser.add_subparsers(dest='command',required=True)
    verify=commands.add_parser('verify')
    verify.add_argument('--emit',type=Path)
    c=commands.add_parser('classify');c.add_argument('a',type=int);c.add_argument('b',type=int)
    args=parser.parse_args()
    if args.command=='classify':
        try:
            result=m.classification((args.a,args.b))
            if args.a+args.b>=4:
                result['two_flexible_witness_gaps']={'fixed_order':str(m.fixed_witness_gap((args.a,args.b))),
                  'uniform_random_order':str(m.random_witness_gap((args.a,args.b))),
                  'threshold':args.a+args.b-1,'singletons':args.a+args.b-3,'flexibles':2}
        except ValueError as exc:
            parser.error(str(exc))
        print(json.dumps(result,indent=2));return
    if args.emit:
        destination=args.emit.resolve()
        if destination==ROOT or ROOT in destination.parents:
            parser.error('--emit must be outside the sealed package.')
        if destination.exists():
            parser.error('Refusing to overwrite an existing output file.')
    result=run()
    if args.emit:
        args.emit.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
        print('Evidence emitted:',args.emit)
    else:
        expected=json.loads((ROOT/'RESULTS.json').read_text())
        require(result==expected,'Computed evidence differs from sealed RESULTS.json.')
        print('SEALED EVIDENCE MATCHES EXACTLY')

if __name__=='__main__':
    main()
