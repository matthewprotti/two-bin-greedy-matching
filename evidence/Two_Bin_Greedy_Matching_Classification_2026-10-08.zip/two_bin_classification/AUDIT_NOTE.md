# Author-side audit note

The all-parameter proof is new and remains unreviewed externally. Its scope includes both a universal fixed-order statement and a separately proved uniform-random-order statement. It does not infer the latter's necessity by averaging a single bad ordering.

## Mathematical adversarial checks

The paired-factorial proof handles zero falling factorials before taking positive ratios. Its interior secant argument only uses points at or above `v-1`. Small cases at gaps zero, one, two and three are explicitly covered. The first-saturation calculation covers the whole finite prefix triangle, not just the boundary time. Earlier singleton rejections in the necessity witness cancel through the common-kernel identity; no assumption that its entire prefix is accepted is made.

The custom polynomial checker verifies six identities by exact coefficient expansion. This is additional author-side evidence, not formalization of the complete theorem. Literal sample-space enumeration is separate from the dynamic program and continuation formula but shares the authoring session.

## Replay repair before release

The first fresh-copy replay completed all substantive mathematical tests but failed the final receipt-object comparison: a newly computed failed-prefix coordinate was a Python tuple, while its JSON round trip was a list. The result field was changed to emit a list explicitly. No probability, theorem statement, substantive JSON receipt, test bound, or inherited source was changed by that serialization repair. The final delivery is re-manifested and must pass fresh-copy replay before release.

## Trust boundaries

A SHA-256 manifest detects byte differences relative to the supplied manifest; it does not establish an authentic author or the mathematical truth of the theorem. The checker and mathematical note must themselves be reviewed. Historical archives are retained unchanged, and their old status labels are not retroactively upgraded.
