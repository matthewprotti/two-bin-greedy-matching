"""Tiny rational-polynomial identity replay; standard library only.

This checks algebraic identities for indeterminates, not the full probabilistic
or inequality theorem. It is not a proof-assistant kernel.
"""
from fractions import Fraction

class Polynomial:
    variables = 4
    def __init__(self, terms=None):
        if isinstance(terms, (int,Fraction)):
            terms = {(0,)*self.variables:Fraction(terms)}
        self.terms = {m:Fraction(v) for m,v in (terms or {}).items() if v}
    @classmethod
    def var(cls,index):
        powers=[0]*cls.variables; powers[index]=1
        return cls({tuple(powers):1})
    @staticmethod
    def coerce(other):
        return other if isinstance(other,Polynomial) else Polynomial(other)
    def __add__(self,other):
        other=self.coerce(other); t=dict(self.terms)
        for m,v in other.terms.items(): t[m]=t.get(m,0)+v
        return Polynomial(t)
    __radd__=__add__
    def __neg__(self): return Polynomial({m:-v for m,v in self.terms.items()})
    def __sub__(self,other): return self+(-self.coerce(other))
    def __rsub__(self,other): return self.coerce(other)+(-self)
    def __mul__(self,other):
        other=self.coerce(other); t={}
        for p,v in self.terms.items():
            for q,w in other.terms.items():
                m=tuple(a+b for a,b in zip(p,q)); t[m]=t.get(m,0)+v*w
        return Polynomial(t)
    __rmul__=__mul__
    def __pow__(self,n):
        if n<0: raise ValueError('Only nonnegative powers.')
        result=Polynomial(1)
        for _ in range(n): result=result*self
        return result
    def __eq__(self,other): return self.terms==self.coerce(other).terms


def verify_identities():
    x,y,z,w=[Polynomial.var(i) for i in range(4)]
    # Product-ratio induction, q=r+d.
    r,d,j=x,y,z; q=r+d
    lhs=(r-j)*(d+j+1)*(d-j)-(q-j)*(d-j-1)*(d+j)
    rhs=d*(2*r-d*(d-1)+j*(j-1))
    assert lhs==rhs
    # Rewriting the square boundary.
    r,q=x,y; N=r+q; d=q-r
    assert N-d*d == 2*r-d*(d-1)
    assert 2*(r*(r-1)+q*(q-1)) == N*N+d*d-2*N
    # Factorization deciding uniform-order counterexample sign.
    N,Z=x,y
    expanded=Z*Z-(N*N+9*N+26)*Z+N**3+10*N*N+24*N
    factored=(Z-N-2)*(Z-N*N)-8*(N+3)*(Z-N)
    assert expanded==factored
    # Factorial-ratio simplification of the random-order witness sum.
    r,q=x,y; N=r+q; Z=(q-r)**2
    P=(Z-N-2)*(Z-N*N)-8*(N+3)*(Z-N)
    Br=r*(r+3)-(r+2)*(q-1)
    Bq=q*(q+3)-(q+2)*(r-1)
    assert 4*(q*Br*(q+2)*(q+3)+r*Bq*(r+2)*(r+3)) == (N+2)*P
    assert ((N+4)**2-Z)*((N+6)**2-Z) == 16*(r+2)*(r+3)*(q+2)*(q+3)
    return {'rational_polynomial_identities':6,
            'scope':'Exact coefficient expansion in a custom rational polynomial ring; not a formalization.'}

if __name__=='__main__':
    print(verify_identities())
