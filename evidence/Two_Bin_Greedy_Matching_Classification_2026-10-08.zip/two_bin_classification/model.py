"""Exact two-bin greedy-matching model; no floating-point arithmetic.

Mathematical soundness comes from PROOF.md, not from these finite checks.
All local implementations were authored by the same AI-assisted session.
"""
from __future__ import annotations
from collections import defaultdict
from fractions import Fraction
from functools import lru_cache
from math import comb
from typing import Iterable

F = Fraction
ALGORITHMS = ('rv', 'rank0', 'rank1')

def validate_caps(caps: tuple[int, int]) -> tuple[int, int]:
    if len(caps) != 2 or any(type(x) is not int or x < 1 for x in caps):
        raise ValueError('Exactly two positive integer capacities are required.')
    return caps

def binom(n: int, k: int) -> int:
    if n < 0:
        raise ValueError('Trial count cannot be negative.')
    return comb(n, k) if 0 <= k <= n else 0

@lru_cache(None)
def cdf_counts(n: int) -> tuple[int, ...]:
    if n < 0:
        raise ValueError('Trial count cannot be negative.')
    out = [0]
    for k in range(n + 1):
        out.append(out[-1] + comb(n, k))
    return tuple(out)

def window_count(n: int, lo: int, hi: int) -> int:
    if lo > hi or hi < 0 or lo > n:
        return 0
    c = cdf_counts(n)
    return c[min(n, hi) + 1] - c[max(0, lo)]

def falling(x: int, k: int) -> int:
    if x < 0 or k < 0:
        raise ValueError('Falling factorial arguments must be nonnegative.')
    if k > x:
        return 0
    out = 1
    for j in range(k):
        out *= x - j
    return out

def classification(caps: tuple[int, int]) -> dict:
    a, b = sorted(validate_caps(caps))
    d, N = b-a, a+b-2
    if a == 1 and b <= 2:
        regime = 'UNIVERSAL_EQUALITY'
    elif a == 1:
        regime = 'RANKING_UNIVERSALLY_DOMINATES_WITH_STRICT_EXAMPLES'
    elif d*d <= N:
        regime = 'RV_UNIVERSALLY_DOMINATES_WITH_STRICT_EXAMPLES'
    else:
        regime = 'NO_UNIVERSAL_DOMINANCE_IN_EITHER_DIRECTION'
    return {'capacities': [a, b], 'gap_squared': d*d, 'total_minus_two': N,
            'rv_universal': d*d <= N, 'regime': regime,
            'arrival_models': ['every independent fixed degree order',
                               'independent uniform random arrival order'],
            'scope': 'Independent uniform singleton neighborhoods; fair independent ranking priority.'}

def survival_numerators(caps: tuple[int, int], t: int, s: int) -> tuple[int, int]:
    """RV and RK numerators, both on denominator 2**(t+1)."""
    a, b = validate_caps(caps)
    if t < 0 or not 0 <= s <= t:
        raise ValueError('Invalid prefix length/singleton count.')
    lo, hi, f = t-b+1, a-1, t-s
    v = 2*window_count(t, lo, hi)
    r = (window_count(s, lo, hi) + window_count(s, lo-f, hi-f)) << f
    return v, r

def survival(caps: tuple[int, int], t: int, s: int, algorithm: str) -> F:
    v, r = survival_numerators(caps, t, s)
    if algorithm not in ('rv', 'ranking'):
        raise ValueError('Algorithm must be rv or ranking.')
    return F(v if algorithm == 'rv' else r, 1 << (t+1))

def advance(law: dict[tuple[int, int], int], caps: tuple[int, int],
            degree: int, algorithm: str) -> dict[tuple[int, int], int]:
    """One-job DP; each step doubles the integer denominator, even when deterministic."""
    if degree not in (0, 1, 2) or algorithm not in ALGORITHMS:
        raise ValueError('Invalid degree or algorithm.')
    out: dict[tuple[int, int], int] = defaultdict(int)
    for (x, y), w in law.items():
        open0, open1 = x < caps[0], y < caps[1]
        if degree == 0 or not (open0 or open1):
            out[x, y] += 2*w
        elif degree == 1:
            out[x+1, y] += w if open0 else 0
            out[x, y+1] += w if open1 else 0
            out[x, y] += w*((not open0) + (not open1))
        elif not open0:
            out[x, y+1] += 2*w
        elif not open1:
            out[x+1, y] += 2*w
        elif algorithm == 'rv':
            out[x+1, y] += w
            out[x, y+1] += w
        elif algorithm == 'rank0':
            out[x+1, y] += 2*w
        else:
            out[x, y+1] += 2*w
    return {k: v for k, v in out.items() if v}

def size_counts(law: dict[tuple[int, int], int]) -> dict[int, int]:
    out: dict[int, int] = defaultdict(int)
    for (x, y), w in law.items():
        out[x+y] += w
    return dict(out)

def process_distribution(caps: tuple[int, int], seq: Iterable[int], algorithm: str) -> dict[int, F]:
    validate_caps(caps)
    seq = tuple(seq)
    if algorithm == 'ranking':
        p = process_distribution(caps, seq, 'rank0')
        q = process_distribution(caps, seq, 'rank1')
        return {k: (p.get(k, F(0)) + q.get(k, F(0)))/2 for k in sorted(p.keys() | q.keys())}
    if algorithm not in ALGORITHMS:
        raise ValueError('Unknown algorithm.')
    law = {(0, 0): 1}
    for d in seq:
        law = advance(law, caps, d, algorithm)
    return {k: F(v, 1 << len(seq)) for k, v in size_counts(law).items()}

def kernel_distribution(caps: tuple[int, int], seq: Iterable[int], algorithm: str) -> dict[int, F]:
    validate_caps(caps)
    seq0 = tuple(seq)
    if any(d not in (0,1,2) for d in seq0):
        raise ValueError('Degrees must be 0, 1 or 2.')
    seq = tuple(d for d in seq0 if d)
    n = len(seq)
    if not n:
        return {0: F(1)}
    counts = [0]
    for d in seq:
        counts.append(counts[-1] + (d == 1))
    surv = [survival(caps, t, counts[t], algorithm) for t in range(n)]
    weights = [(t, surv[t-1]-surv[t]) for t in range(1,n)] + [(n,surv[n-1])]
    out: dict[int,F] = defaultdict(F)
    for t, w in weights:
        if w < 0:
            raise AssertionError('Invalid first-saturation distribution.')
        s = counts[n]-counts[t]
        f = n-t-s
        for j in range(s+1):
            out[min(sum(caps), t+f+j)] += w*F(comb(s,j), 1 << s)
    return {k:v for k,v in out.items() if v}

def random_order_counts(caps: tuple[int,int], singles: int, flexibles: int,
                        algorithm: str) -> dict[int,int]:
    """Sums over all distinct degree words; denominator 2**n * binom(n,flexibles)."""
    validate_caps(caps)
    if min(singles,flexibles) < 0 or algorithm not in ALGORITHMS:
        raise ValueError('Invalid profile/algorithm.')
    states = {(0,0): {(0,0):1}}
    n = singles+flexibles
    for t in range(n+1):
        for f in range(max(0,t-singles), min(flexibles,t)+1):
            s = t-f
            law = states.pop((s,f))
            if s == singles and f == flexibles:
                return size_counts(law)
            for degree, key in ((1,(s+1,f)), (2,(s,f+1))):
                if key[0] > singles or key[1] > flexibles:
                    continue
                out = advance(law,caps,degree,algorithm)
                dest = states.setdefault(key,{})
                for load,w in out.items():
                    dest[load] = dest.get(load,0)+w
    raise AssertionError('Unreachable profile.')

def random_order_distribution(caps: tuple[int,int], singles: int, flexibles: int,
                              algorithm: str) -> dict[int,F]:
    if algorithm == 'ranking':
        a = random_order_distribution(caps,singles,flexibles,'rank0')
        b = random_order_distribution(caps,singles,flexibles,'rank1')
        return {k: (a.get(k,F(0))+b.get(k,F(0)))/2 for k in sorted(a.keys() | b.keys())}
    n = singles+flexibles
    den = (1 << n)*comb(n,flexibles)
    return {k:F(v,den) for k,v in random_order_counts(caps,singles,flexibles,algorithm).items()}

def fixed_witness_gap(caps: tuple[int,int]) -> F:
    """RV minus RK at K=S-1 for 1**(S-4),2,2,1; requires S>=4."""
    a,b = sorted(validate_caps(caps))
    N,d = a+b-2,b-a
    if N < 2:
        raise ValueError('This witness requires total capacity at least four.')
    return F(comb(N,a-1)*(N-d*d), (1 << N)*2*N*(N-1))

def random_witness_gap(caps: tuple[int,int]) -> F:
    """RV minus RK at K=S-1: two flexibles, S-3 singletons, uniform order."""
    a,b = sorted(validate_caps(caps))
    N,d = a+b-2,b-a
    if N < 2:
        raise ValueError('This witness requires total capacity at least four.')
    z = d*d
    P = (z-N-2)*(z-N*N) - 8*(N+3)*(z-N)
    D = ((N+4)**2-z)*((N+6)**2-z)
    return F(comb(N,a-1)*2*(N+2)*P, (1 << N)*N*D)

def random_witness_sum(caps: tuple[int,int]) -> F:
    """Unsimplified combinatorial sum, independent of polynomial factorization."""
    a,b = sorted(validate_caps(caps))
    r,q,N = a-1,b-1,a+b-2
    n = N+1
    if n < 3:
        raise ValueError('This witness requires total capacity at least four.')
    total = 0
    for t in range(2,n):
        total += comb(t,2)*(binom(t-2,r-1)+binom(t-2,q-1)
                            -binom(t-2,r)-binom(t-2,q))
    return F(total, (1 << n)*comb(n,2))
