"""Hash-check this package; run the exact checks in an isolated temporary copy."""
from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import sys
import tempfile

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent

def verify_manifest(root):
    manifest=json.loads((root/'MANIFEST.json').read_text())
    expected=manifest['files']
    actual={p.relative_to(root).as_posix() for p in root.rglob('*')
            if p.is_file() and '__pycache__' not in p.parts and p.name!='MANIFEST.json'}
    if actual != set(expected):
        raise RuntimeError({'missing':sorted(set(expected)-actual),'extra':sorted(actual-set(expected))})
    for name,record in expected.items():
        path=root/name
        if path.is_symlink() or not path.resolve().is_relative_to(root.resolve()):
            raise RuntimeError('Unsafe package path: '+name)
        data=path.read_bytes()
        if len(data)!=record['bytes'] or hashlib.sha256(data).hexdigest()!=record['sha256']:
            raise RuntimeError('Integrity mismatch: '+name)
    return len(expected)

def main():
    count=verify_manifest(ROOT)
    print(f'Manifest membership, sizes and SHA-256: PASS ({count} files)',flush=True)
    with tempfile.TemporaryDirectory(prefix='two-bin-classification-') as directory:
        dest=Path(directory)/'package'
        shutil.copytree(ROOT,dest,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
        verify_manifest(dest)
        subprocess.run([sys.executable,'-B','check.py','verify'],cwd=dest,check=True)
        verify_manifest(dest)
    verify_manifest(ROOT)
    print('FRESH-COPY REPLAY PASS; original and copied package bytes unchanged',flush=True)

if __name__=='__main__':
    main()
