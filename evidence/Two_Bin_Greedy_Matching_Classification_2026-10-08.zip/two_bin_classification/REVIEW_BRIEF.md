# Review brief: a sharp two-bin capacity classification

This request is for a new mathematical review, not confirmation of the earlier adjacent-capacity result. The user supplied a positive review of the adjacent-capacity proof; that review did not cover the subsequent gap-two addendum or this classification. The new proof is self-contained.

## Claim under review

For the stated independent uniform-neighborhood two-bin model with a fair independent RK priority, RV dominates in every matching-size tail for all finite workloads exactly when `(b-a)^2 <= a+b-2`. Necessity and sufficiency are claimed both for the universal fixed-order model and, separately, for the uniform random-arrival model.

The manuscript additionally claims universal equality only at `(1,1),(1,2)`; universal RK dominance when the smaller capacity is one; and no universal ordering outside the RV region when the smaller capacity is at least two.

## Highest-value checks

1. **Paired factorial inequality, Section 2.** Check zero-support cases; the split at `max(u,v)>=d`; the exact product-ratio induction numerator; and the claim that the symmetric secant polynomial has nonnegative coefficients throughout the required interior range. Verify that no positivity or division assertion fails at `(r,q)=(1,3)` or `(3,6)`.
2. **First-saturation bridge, Section 3.** Check both branches of the reflected RK interval, the Pascal difference, and the substitution `u=N-t+1,v=t-s-1`. The proof must cover all prefixes, not merely the final survivor state.
3. **Common continuation, Section 4.** Check future independence under saturation conditioning, truncation, impossible values of `L`, degree-zero deletion, and the summation-by-parts identity.
4. **Necessity in two distinct arrival models, Sections 5--6.** The fixed witness can contain earlier singleton rejections; the cancellation argument, not an all-accepted-prefix assumption, handles them. The uniform-order theorem needs its own calculation. Check equations (18)--(24), parity, the range `N+2 <= d^2 <= N^2`, and positivity of the denominator.
5. **Classification quantifiers, Section 7.** “Neither universally dominates” must not be mistaken for crossing tails on every workload. Strictness examples must work in both arrival models.

## Computational review

Run `python -B REPLAY.py`. Finite tests compare all prefix inequalities for 2,080 capacity pairs through 64, paired factorial inequalities, direct dynamic programming, literal enumeration, and explicit fixed/random-order witness distributions. `RESULTS.json` states every executed bound and count.

The literal oracle does not import the main model but has the same authorship provenance. `algebra.py` checks polynomial identities, not all proof obligations. A passing replay is not itself an all-parameter formalization or an external proof audit.

## Requested disposition

Return exact theorem scope accepted, any counterexample or missing premise, any required proof repair, and an explicit distinction between author-side evidence, your review, formalization, and novelty assessment. Do not overwrite historical sources or infer that the three-bin conjecture has been proved.
