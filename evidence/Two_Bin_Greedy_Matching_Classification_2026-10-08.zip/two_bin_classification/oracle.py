"""Small literal sample-space oracle. Does NOT import model.py.

Enumerates singleton neighborhoods, RV's fresh preference bits, and RK's single
priority bit. This is a different implementation, not independent authorship.
"""
from collections import Counter
from fractions import Fraction
from itertools import product


def enumerate_distribution(capacities, degrees, algorithm):
    caps = tuple(capacities)
    seq = tuple(degrees)
    if len(caps) != 2 or min(caps) < 1 or any(d not in (0,1,2) for d in seq):
        raise ValueError('Invalid literal instance.')
    if algorithm not in ('rv','ranking'):
        raise ValueError('Invalid algorithm.')
    single_positions = [i for i,d in enumerate(seq) if d == 1]
    flexible_positions = [i for i,d in enumerate(seq) if d == 2]
    counts = Counter()
    samples = 0
    for singleton_bits in product((0,1),repeat=len(single_positions)):
        neighborhoods = {i:(bit,) for i,bit in zip(single_positions,singleton_bits)}
        for i in flexible_positions:
            neighborhoods[i] = (0,1)
        random_bits = len(flexible_positions) if algorithm == 'rv' else 1
        for bits in product((0,1),repeat=random_bits):
            if algorithm == 'rv':
                priority = {i:bit for i,bit in zip(flexible_positions,bits)}
            else:
                priority = {i:bits[0] for i in flexible_positions}
            load = [0,0]
            for i,d in enumerate(seq):
                if not d:
                    continue
                available = [v for v in neighborhoods[i] if load[v] < caps[v]]
                if len(available) == 2:
                    chosen = priority[i]
                elif available:
                    chosen = available[0]
                else:
                    continue
                load[chosen] += 1
            counts[sum(load)] += 1
            samples += 1
    return {k:Fraction(v,samples) for k,v in counts.items()}, samples
